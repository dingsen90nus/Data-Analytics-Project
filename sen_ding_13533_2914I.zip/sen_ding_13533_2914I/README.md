a. Full name (as in NRIC) and email address.

    Ding Sen     e0335935@u.nus.edu
    
b. Overview of the submitted folder and the folder structure.

	- Data
	 
	  (not submitted in entries, but originally included the data db file to run the programme at shell) 
	 
       - eda
     
     		- containing data explorations and 
		- model fitting and comparison
		- selected model was put to the .py files in mlp folder. 
		
     - mlp
     
            - main.py ( a simpler programme)
            - more_sophisticated_pipeline.py ( a full pipeline) 
            
     - requirements.txt
     
     - run.sh
     
    

c. Instructions for executing the pipeline and modifying any parameters.

	- run terminal move to the directory . (Key: 'ls'  - list all. 'cd' xx go to xx directory. )
	- run 'sh run.sh' at terminal
	
	- You can choose the choice of models. Or specific tuning parameters associated with the specific models. 

d. Description of logical steps/flow of the pipeline. If you find it useful, please feel free
to include suitable visualization aids (eg, flow charts) within the README.

-    A more sophisticated Model

	Text data --> NLP
	Numeric data 
	
	--> both together fit into the Gradient Boost Algorithms. 


-    A Simple Model


e. Overview of key fni dings from the EDA conducted in Task 2 and the choices made
in the pipeline based on these findings, particularly any feature engineering. Please keep the details of the EDA in the `.ipynb`, this section should be a quick summary.

	- Key Findings: 
		1. Timing data is important to predict traffic volume
		2. Feature Engineering
			- Timing data can be decomposed, to variables such as days of a week, hours of day, holidays.. 
			- Categorical Variables are labeled and encoded
			- Text data is processed by NLP algorithms. 
			
			all these are could be variables affecting traffic volume
			
		3. We can use weather text data for prediction. 
		
	the prediction results are remarkably accurate. 
		
		
f. Explanation of your choice of models for each machine learning task.

	- I used Gradient Boost Model, and some NLP algorithms to put the data as inputs methods. 
	- I compared performance of several models, including parameter selections. 
	- Overall a simple GB model performs good. with the tuning parameter - max_depth set at 9.

g. Evaluation of the models developed. Any metrics used in the evaluation should
also be explained.

	- RMSE( Root Mean Square Error) was the key metrics. Evaluating Model performance, after we divide data into 70 - training and 30 - test. 

h. Other considerations for deploying the models developed.
	
	- Timing and weather variables turn out to be highly accurate in predicting traffic volume. It has remarkable explainable power. 
