#!/bin/bash
python ./mlp/main.py
python ./mlp/more_sophisticated_pipeline.py