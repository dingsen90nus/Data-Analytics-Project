#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 12:32:42 2020

@author: dingsen
"""
import pandas as pd
from sqlalchemy import create_engine
from sklearn.preprocessing import LabelEncoder

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.metrics import mean_squared_error

import matplotlib.pyplot as plt
from math import sqrt

def read_file():
    engine = create_engine('sqlite:///data/traffic.db')
    df = pd.read_sql_query("SELECT * FROM traffic WHERE date_time >= '2013-01-01 00:00:00'", engine)
    return df

def preprocess(df):
    df['date_time'] = pd.to_datetime(df.date_time)
    df['year']= df.date_time.dt.year
    df['month']= df.date_time.dt.month
    df['week']= df.date_time.dt.weekofyear
    df['hour'] = df.date_time.dt.hour
    
    df['dayofmonth']= df.date_time.dt.day
    df['dayofweek']= df.date_time.dt.dayofweek
 
    le = LabelEncoder()
        # Create new features
    df['holiday_enc'] = le.fit_transform(df['holiday'])
    df['weather_main_enc'] =  le.fit_transform(df['weather_main'])
    df['weather_description_enc'] =  le.fit_transform(df['weather_description'])
    return df

def fit_predict_model(df):
    features = ['temp','rain_1h','snow_1h','clouds_all','hour','dayofweek', 
   'holiday_enc', 'weather_main_enc', 'weather_description_enc', 
           'year','month', 'week', 'dayofmonth']
    
    train, test = train_test_split(df, test_size=0.3,  random_state=123)
    pl = Pipeline([
        ('GradientBoostingRegressor', GradientBoostingRegressor(max_depth = 9 ))
    ])
    pl.fit(train[features], train.traffic_volume)
    test['pred'] = pl.predict(test[features])
    return test

def plotgraph(df):
    # Data
    df=pd.DataFrame({'x': range(20), 'y1': df.traffic_volume.head(20), 'y2': df.pred.head(20) })
    # multiple line plot
    plt.plot(df['x'], df['y1'],  marker='o', markerfacecolor='blue', markersize=12, color='skyblue', linewidth=4, label="True Value")
    plt.plot(df['x'], df['y2'], marker='', color='olive', linewidth=2, label="pred" )
    plt.legend()

def print_metrics(test):
# Measure the local RMSE
    rmse = sqrt(mean_squared_error(test['traffic_volume'], test['pred']))
    print('RMSE for Baseline I - Simple Gradient Boost model: {:.3f}'.format(rmse))
    print(test[['traffic_volume', 'pred']].head(10))

def main_run():
    df = read_file()
    df = preprocess(df)
    test = fit_predict_model(df)
    plotgraph(test)
    print_metrics(test)

main_run()